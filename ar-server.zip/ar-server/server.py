import http.server
import socketserver
import os

class DJango(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        # Try to serve the file directly
        file_path = self.translate_path(self.path)
        if os.path.exists(file_path) and os.path.isfile(file_path):
            # If file exists, serve it normally
            super().do_GET()
        else:
            # Otherwise redirect to index.html
            self.path = '/index.html'
            super().do_GET()

# Set port and directory to serve
PORT = 8080
DIRECTORY = "."  # Change to your build directory if different

# Change to the directory containing your built files
os.chdir(DIRECTORY)

# Start the server
with socketserver.TCPServer(("", PORT), DJango) as httpd:
    print(f"Serving at http://localhost:{PORT}")
    httpd.serve_forever()